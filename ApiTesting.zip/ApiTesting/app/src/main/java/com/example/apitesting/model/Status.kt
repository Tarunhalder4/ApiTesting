package com.example.apitesting.model

data class Status(
    val status: String
)