package com.example.apitesting

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast

class LoginActivity : AppCompatActivity() {
    private lateinit var emailEditTextView: EditText
    private lateinit var passwordEditTextView:EditText
    private lateinit var loginBtn:Button
    private lateinit var signUp:Button
    private lateinit var  myPref:MyPref

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_login)

        emailEditTextView = findViewById(R.id.email)
        passwordEditTextView = findViewById(R.id.password)
        loginBtn = findViewById(R.id.login)
        signUp = findViewById(R.id.sigup)

        myPref = MyPref(this)

        loginBtn.setOnClickListener {
            logIn()
        }

        signUp.setOnClickListener {
            val intent  = Intent(this@LoginActivity,RegistrationActivity::class.java)
            startActivity(intent)
            finish()
        }

    }

    fun logIn(){
        if(emailEditTextView.text.toString() == myPref.getEmail() &&
            passwordEditTextView.text.toString() == myPref.getPassword()
        ){
            val intent  = Intent(this,MainActivity::class.java)
            startActivity(intent)
        }else{
            Toast.makeText(this,"please registration", Toast.LENGTH_SHORT).show()
        }
    }
}