package com.example.apitesting.model

data class Book(
    val available: Boolean,
    val id: Int,
    val name: String,
    val type: String
)