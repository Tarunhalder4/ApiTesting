package com.example.apitesting

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.text.TextUtils
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast

class RegistrationActivity : AppCompatActivity() {
    private lateinit var  emailEditTextView: EditText
    private lateinit var passEditTextView: EditText
    private lateinit var confromPassEditTextView: EditText
    private lateinit var logIn: Button
    private lateinit var signUp:Button
    private lateinit var myPref:MyPref

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_registration)

        emailEditTextView = findViewById(R.id.email)
        passEditTextView = findViewById(R.id.password)
        confromPassEditTextView = findViewById(R.id.confrom_password)
        logIn = findViewById(R.id.login)
        signUp  = findViewById(R.id.signup)

        myPref = MyPref(this)


        logIn.setOnClickListener {
            val intent  = Intent(this@RegistrationActivity,LoginActivity::class.java)
            startActivity(intent)
            finish()
        }

        signUp.setOnClickListener {
            userSignUp()
        }




    }

    private fun userSignUp(){
        if(!TextUtils.isEmpty(emailEditTextView.text.toString())&&
            !TextUtils.isEmpty(passEditTextView.text.toString())&&
            !TextUtils.isEmpty(confromPassEditTextView.text.toString())){

            if(passEditTextView.text.toString().equals(confromPassEditTextView.text.toString())){
                myPref.saveData(emailEditTextView.text.toString(),passEditTextView.text.toString())
                val intent  = Intent(this,MainActivity::class.java)
                startActivity(intent)
            }else{
                Toast.makeText(this,"password and Conform Password is not match",Toast.LENGTH_SHORT).show()
            }

        }else{
            Toast.makeText(this,"please fill all field",Toast.LENGTH_SHORT).show()
        }

    }


}