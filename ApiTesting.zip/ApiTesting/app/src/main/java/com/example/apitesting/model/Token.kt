package com.example.apitesting.model

data class Token(
    val accessToken: String
)