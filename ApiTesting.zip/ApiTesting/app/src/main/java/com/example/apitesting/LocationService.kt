package com.example.apitesting

import android.app.Service
import android.content.Intent
import android.media.MediaPlayer
import android.os.Binder
import android.os.IBinder
import android.provider.Settings

class LocationService:Service(){
    private lateinit var binder: Binder
    private lateinit var mediaPlayer: MediaPlayer

    inner class MyService():Binder(){
        fun getService():LocationService{
            return this@LocationService
        }
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        super.onStartCommand(intent, flags, startId)
        mediaPlayer = MediaPlayer.create(this,Settings.System.DEFAULT_RINGTONE_URI)
        mediaPlayer.start()

        return START_STICKY
    }


    override fun onBind(p0: Intent?): IBinder? {
      // return binder
        return null
    }

    override fun onDestroy() {
        super.onDestroy()
        stopMusic()
    }

    fun playMusic(){
        if(!mediaPlayer.isPlaying)
            mediaPlayer.start()
    }

    fun stopMusic(){
        if(mediaPlayer.isPlaying)
            mediaPlayer.stop()
    }

}