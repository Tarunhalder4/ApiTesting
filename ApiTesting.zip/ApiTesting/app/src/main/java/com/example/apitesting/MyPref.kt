package com.example.apitesting

import android.content.Context

class MyPref constructor(context: Context){
    companion object{
        const val EMAIL = "email"
        const val PASSWORD = "PASSWORD"
    }

    private val sharedPref = context.getSharedPreferences("UserData", Context.MODE_PRIVATE)

    fun saveData(email:String,password:String){
        val editor = sharedPref.edit()
        editor.putString(EMAIL,email)
        editor.putString(PASSWORD,password)
        editor.apply()
    }

    fun getEmail():String?{
        return sharedPref.getString(EMAIL,"")
    }

    fun getPassword():String?{
        return sharedPref.getString(PASSWORD,"")
    }


}