package com.example.apitesting.model

data class CreateBookOrder(
    val created: Boolean,
    val orderId: String
)